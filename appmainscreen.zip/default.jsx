import React, { Component } from 'react';
import { Text, TextInput, View, StyleSheet, Image, AppRegistry, Dimensions, TouchableHighlight } from 'react-native';
import Constants from 'expo-constants';

let deviceHeight = Dimensions.get('window').height;
let deviceWidth = Dimensions.get('window').width;

export default class App extends Component {
    state = {
      cities: ['Salt Lake City','New York City','Denver','Miami','Seattle','Las Vegas','Detroit','Columbus','Orlando','Minneapolis','Washington, D.C.'],
      recipient: '',
      message: ' ',
      newItemInput: '',
      selectedValue: '',
      locations :[],
      object : {}
    }
    
    
    addItem(e){
    e.preventDefault();
    const newItemInput = this.state.newItemInput;
    const newRadioValue = this.state.selectedValue;
    const obj = {'item':newItemInput, 'columnType':newRadioValue};
    const newArray = this.state.locations.slice(); // Create a copy
    newArray.push(obj); // Push the object
    this.setState({ locations: newArray });
    console.log(this.state.locations);       
}
// code from stackOverflow
handleChange=(event)=> {
    this.setState({
      ...this.state,
      selectedValue: event.target.value
    });
  };

  change (event){
    this.setState({
      [event.target.name]:event.target.value
    });
  };
  
    render() {
        return (
            <View style={styles.container}>
                <View style={styles.contentContainer}>
                <View style={styles.navbarContainer}>
                
                
                </View>
                <Image
                    source={{ uri: 'https://media.wired.com/photos/59269cd37034dc5f91bec0f1/master/w_582,c_limit/GoogleMapTA.jpg' }}
                    style={{ height: 350, width: 275 }}
                />
                
            
                </View>
                
                <View style={styles.navbarContainer}>
                <TextInput style={styles.playerControlsContainer}
                    onChangeText={(message) => this.setState({message})}
                    value={this.state.message}
                    />
                <TouchableHighlight
                        onPress={() => 
                            () => {this.addItem(this.state.message)}
                        }
                    >
                    
                    <Image
                        source={{ uri: 'https://cdn4.iconfinder.com/data/icons/defaulticon/icons/png/256x256/add.png' }}
                        style={styles.navButtons}
                    />
                    </TouchableHighlight>
                    
                    
                </View>
            </View>
        );
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        backgroundColor: '#41B3A3',
    },
    topText: {
        fontFamily: 'Arial',
        fontSize: 14,
        color: 'white',
        paddingTop: 30,
        paddingBottom: 20,
    },
    playerControlsContainer: {
        height: 25,
        width: 150,
        backgroundColor: 'white',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        borderTopWidth: 3,
        borderColor: 'white',
    },
    navButtons: {
        margin: 25,
        height: 40,
        width: 30,
    },
    contentContainer: {
        height: 5*(deviceHeight/6),
        width: deviceWidth,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white',
    },
    navbarContainer: {
        height: deviceHeight/6,
        width: deviceWidth,
        backgroundColor: 'grey',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        borderTopWidth: 3,
        borderColor: 'white',
    },
    navButton: {
        height: deviceHeight/14,
        width: deviceWidth/4,
        backgroundColor: 'white',
        borderColor: 'blue',
        borderWidth: 2,
        alignItems: 'center',
        justifyContent: 'center',
        margin: 20,
    },

});